# Digital Support Systems, Inc. — Website Starter (Next.js + Tailwind)

## Quick start
1. Install dependencies
   npm install

2. Run dev server
   npm run dev

3. Open
   http://localhost:3000

## Pages
- /
- /about
- /services/access-control
- /services/it-infrastructure
- /case-studies
- /contact

## Next step (recommended)
Wire the contact form to an API route that sends email (SendGrid/Resend), add SEO metadata per page, and replace placeholders with real project case studies.
